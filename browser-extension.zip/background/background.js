let latestChatData = null;
const conversationStore = new Map();
let conversationCounter = 1;

// 保留HTML格式，不进行转换
function stripHtmlTags(html) {
  if (!html || typeof html !== 'string') return html;
  
  // 直接返回原始HTML内容，不进行任何转换
  return html;
}

const PLATFORMS = {
  'claude': {
    script: 'content_scripts/claude.js',
    triggerAction: 'export-claude-content'
  },
  'deepseek': {
    script: 'content_scripts/deepseek.js',
    triggerAction: 'export-deepseek-content'
  },
  'gemini': {
    script: 'content_scripts/gemini.js',
    triggerAction: 'export-gemini-content'
  },
  'chatgpt': {
    script: 'content_scripts/chatgpt.js',
    triggerAction: 'export-chatgpt-content'
  }
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const { action } = request;

  // Handle export triggers from popup
  const exportPlatformName = action && action.startsWith('export-') ? action.substring('export-'.length) : null;
  if (exportPlatformName && PLATFORMS[exportPlatformName]) {
    console.log(`[AI-ThreadStash] Received export request for ${exportPlatformName}`);
    const platform = PLATFORMS[exportPlatformName];

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs.length > 0) {
        const activeTab = tabs[0];
        console.log(`[AI-ThreadStash] Preparing to inject ${exportPlatformName} content script into tab ${activeTab.id}`);
        
        chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          files: [platform.script]
        }, () => {
          if (chrome.runtime.lastError) {
            console.error(`[AI-ThreadStash] Error injecting ${exportPlatformName} script:`, chrome.runtime.lastError.message);
            sendResponse({ success: false, message: `Injection failed: ${chrome.runtime.lastError.message}` });
            return;
          }
          console.log(`[AI-ThreadStash] ${exportPlatformName} content script injected. Waiting for initialization...`);
          
          // 添加延迟确保content script完全初始化
          setTimeout(() => {
            console.log(`[AI-ThreadStash] Triggering ${exportPlatformName} export...`);
            // 直接调用内容脚本并等待响应
            chrome.tabs.sendMessage(activeTab.id, { action: platform.triggerAction }, (response) => {
              if (chrome.runtime.lastError) {
                console.error(`[AI-ThreadStash] Error triggering ${exportPlatformName} export:`, chrome.runtime.lastError.message);
                sendResponse({ success: false, message: chrome.runtime.lastError.message });
              } else {
                console.log(`[AI-ThreadStash] ${exportPlatformName} export triggered, response:`, response);
                // 内容脚本现在会直接发送content-ready或content-failed消息
                sendResponse({ success: true, message: 'Export triggered successfully' });
              }
            });
          }, 500); // 500ms延迟确保content script初始化完成
        });
      } else {
        console.error(`[AI-ThreadStash] No active tab found for ${exportPlatformName}`);
        sendResponse({ success: false, message: 'No active tab found' });
      }
    });
    return true; // async response
  }

  // Generic content-ready handler
  if (action && action.endsWith('-content-ready')) {
    const platformName = action.split('-')[0];
    console.log(`[AI-ThreadStash] Received ${platformName} content from content script`, action, request.data);
    try {
      // Convert data format if needed (for Gemini compatibility)
      let data = request.data;
      if (data.messages && !data.turns) {
        console.log(`[AI-ThreadStash] Converting Gemini data format from messages to turns`);
        console.log(`[AI-ThreadStash] Original messages:`, data.messages);
        
        // Convert { title, messages } format to { title, turns } format
        data = {
          title: data.title,
          url: data.url || '',
          exportedAt: data.exportedAt || new Date().toISOString(),
          turns: data.messages.map(msg => ({
            role: msg.author === 'User' ? 'user' : 'assistant',
            content: {
              text: typeof msg.content === 'string' ? stripHtmlTags(msg.content) : stripHtmlTags(String(msg.content)),
              html: msg.content // Keep original HTML for formatting
            }
          }))
        };
        console.log(`[AI-ThreadStash] Converted data:`, data);
        
        // 调试：检查第一个转换后的消息
        if (data.turns && data.turns.length > 0) {
          console.log(`[AI-ThreadStash] First converted turn:`, data.turns[0]);
          console.log(`[AI-ThreadStash] First turn html length:`, data.turns[0].content.html ? data.turns[0].content.html.length : 'null');
          console.log(`[AI-ThreadStash] First turn text length:`, data.turns[0].content.text ? data.turns[0].content.text.length : 'null');
        }
      }
      openPreviewPage(data);
    } catch (e) {
      console.error(`[AI-ThreadStash] Error opening preview page (${platformName}):`, e);
    }
    // 关键修复：向内容脚本返回一个确认响应，避免“message port closed”错误
    try { sendResponse({ success: true, received: true }); } catch (e) { /* ignore */ }
    return; 
  }

  // Generic content-failed handler
  if (action && action.endsWith('-content-failed')) {
    const platformName = action.split('-')[0];
    console.error(`[AI-ThreadStash] ${platformName} content extraction failed:`, request.error);
    // Open preview page with error message
    openPreviewPage({
        title: `导出失败 - ${platformName.charAt(0).toUpperCase() + platformName.slice(1)}`,
        url: '',
        exportedAt: new Date().toISOString(),
        turns: [{ role: 'system', content: { text: `从 ${platformName} 导出内容失败。\n\n错误信息: ${request.error}` } }]
    });
    // 关键修复：返回确认响应给内容脚本，避免端口关闭报错
    try { sendResponse({ success: true, received: true }); } catch (e) { /* ignore */ }
    return;
  }

  // Keep existing preview data fetch
  if (action === 'get-preview-data') {
    console.log('[AI-ThreadStash] Received request for preview data');
    if (latestChatData) {
      sendResponse({ success: true, data: latestChatData });
    } else {
      sendResponse({ success: false, error: 'No data available' });
    }
    return true;
  }

  // Get conversation data by key
  if (action === 'getConversationData') {
    const key = request.key;
    console.log(`[AI-ThreadStash] Received request for conversation data with key: ${key}`);
    
    if (conversationStore.has(key)) {
      const data = conversationStore.get(key);
      sendResponse({ success: true, data });
    } else {
      sendResponse({ success: false, error: 'Conversation data not found' });
    }
    return true;
  }

  // Handle test connection from preview page
  if (action === 'test-connection') {
    console.log(`[AI-ThreadStash] Test connection from tab:`, sender.tab?.id);
    sendResponse({ success: true, message: 'Background connection test successful' });
    return true;
  }

  // Handle preview page ready signal
  if (action === 'preview-page-ready') {
    console.log(`[AI-ThreadStash] Preview page is ready, sender tab:`, sender.tab?.id);
    
    // 检查是否有匹配的预览页面等待数据
    const tabId = sender.tab?.id;
    if (tabId && latestChatData) {
      console.log('[AI-ThreadStash] Sending data to ready preview page...');
      chrome.tabs.sendMessage(tabId, {
        action: 'preview-data',
        data: latestChatData
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('[AI-ThreadStash] Failed to send data to ready preview page:', chrome.runtime.lastError.message);
        } else {
          console.log('[AI-ThreadStash] Data sent to preview page successfully:', response);
        }
      });
    }
    
    sendResponse({ success: true, message: 'Background received ready signal' });
    return true;
  }

  // Handle keep-alive messages from preview page
  if (action === 'keep-alive') {
    console.log('[AI-ThreadStash] Received keep-alive message from preview page');
    sendResponse({ success: true, message: 'Background is alive' });
    return true;
  }
});

function openPreviewPage(data) {
  console.log('[AI-ThreadStash] Storing chat data and opening preview page.', data);
  latestChatData = data;
  
  // Store conversation data with a unique key
  const conversationKey = `conv_${Date.now()}_${conversationCounter++}`;
  conversationStore.set(conversationKey, data);
  
  // Clean up old conversations (keep only last 10)
  if (conversationStore.size > 10) {
    const keys = Array.from(conversationStore.keys());
    for (let i = 0; i < keys.length - 10; i++) {
      conversationStore.delete(keys[i]);
    }
  }
  
  const previewUrl = chrome.runtime.getURL(`preview/preview.html?key=${conversationKey}`);
  
  // 在当前窗口的新标签页中打开预览页面
  chrome.tabs.create({
    url: previewUrl,
    active: true
  }, (newTab) => {
    if (chrome.runtime.lastError) {
      console.error('[AI-ThreadStash] Error creating preview tab:', chrome.runtime.lastError);
      return;
    }
    
    console.log(`[AI-ThreadStash] Created new preview tab with id ${newTab.id}`);
    
    // 预览页面将通过全局消息监听器发送就绪信号
    // 数据将在收到就绪信号时自动发送
    console.log(`[AI-ThreadStash] Preview tab created, waiting for ready signal from tab ${newTab.id}`);
  });
}