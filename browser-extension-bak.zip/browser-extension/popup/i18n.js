// 简单的国际化实现
const i18n = {
    translations: {
        'exportChatGPT': '导出 ChatGPT 对话',
        'exportDeepSeek': '导出 DeepSeek 对话',
        'exportGemini': '导出 Gemini 对话',
        'help': '帮助',
        'detectingPlatform': '检测平台中...',
        'selectExportChatGPT': '选择导出 ChatGPT 对话',
        'selectExportDeepSeek': '选择导出 DeepSeek 对话',
        'selectExportGemini': '选择导出 Gemini 对话',
        'unsupportedPlatform': '不支持的平台',
        'openSupportedPlatform': '请打开支持的对话平台',
        'unknownPage': '未知页面',
        'cannotGetPageInfo': '无法获取页面信息',
        'parsingConversation': '正在解析 {platform} 对话...',
        'injectingScript': '正在注入脚本...',
        'injectionFailed': '脚本注入失败',
        'requestTimeout': '请求超时',
        'parsingFailed': '解析失败',
        'exportSuccess': '导出成功！',
        'exportFailed': '导出失败'
    },
    
    t: function(key, params = {}) {
        let translation = this.translations[key] || key;
        
        // 替换参数
        for (const [param, value] of Object.entries(params)) {
            translation = translation.replace(`{${param}}`, value);
        }
        
        return translation;
    },
    
    getCurrentLanguage: function() {
        return 'zh_CN';
    }
};

// 全局可用
i18n.getCurrentLanguage = i18n.getCurrentLanguage.bind(i18n);
i18n.t = i18n.t.bind(i18n);