// Use the global i18n instance from i18n.js
// No need to create a new instance as it's already created in i18n.js

document.addEventListener('DOMContentLoaded', function() {
    
    const exportChatGPT = document.getElementById('exportChatGPT');
    const exportDeepSeek = document.getElementById('exportDeepSeek');
    const exportGemini = document.getElementById('exportGemini');
    const status = document.getElementById('status');
    const platformName = document.getElementById('platformName');
    const platformInfo = document.getElementById('platformInfo');
    const helpLink = document.getElementById('helpLink');
    
    // Initialize UI text with i18n
    exportChatGPT.textContent = i18n.t('exportChatGPT');
    exportDeepSeek.textContent = i18n.t('exportDeepSeek');
    exportGemini.textContent = i18n.t('exportGemini');
    helpLink.textContent = i18n.t('help');
    platformName.textContent = i18n.t('detectingPlatform');
    
    // 帮助链接点击事件
    helpLink.addEventListener('click', function(e) {
        e.preventDefault();
        // 获取当前语言设置并传递给help页面
        const currentLang = i18n.getCurrentLanguage();
        const helpUrl = chrome.runtime.getURL('help.html') + '?lang=' + currentLang;
        chrome.tabs.create({
            url: helpUrl
        });
    });
    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        const currentTab = tabs[0];
        
        if (currentTab && currentTab.url) {
            let platform = '';
            let platformIcon = '🤖';
            
            if (currentTab.url.includes('chat.openai.com') || currentTab.url.includes('chatgpt.com')) {
                platform = 'ChatGPT';
                platformIcon = '🤖';
                exportChatGPT.disabled = false;
                exportDeepSeek.disabled = true;
                status.textContent = i18n.t('selectExportChatGPT');
            } else if (currentTab.url.includes('chat.deepseek.com')) {
                platform = 'DeepSeek';
                platformIcon = '🧠';
                exportChatGPT.disabled = true;
                exportDeepSeek.disabled = false;
                exportGemini.disabled = true;
                status.textContent = i18n.t('selectExportDeepSeek');
            } else if (currentTab.url.includes('gemini.google.com')) {
                platform = 'Gemini';
                platformIcon = '✨';
                exportChatGPT.disabled = true;
                exportDeepSeek.disabled = true;
                exportGemini.disabled = false;
                status.textContent = i18n.t('selectExportGemini');
            } else {
                platform = i18n.t('unsupportedPlatform');
                platformIcon = '❌';
                exportChatGPT.disabled = true;
                exportDeepSeek.disabled = true;
                exportGemini.disabled = true;
                status.textContent = i18n.t('openSupportedPlatform');
            }
            
            platformName.textContent = platform;
            platformInfo.querySelector('.platform-icon').textContent = platformIcon;
        } else {
            platformName.textContent = i18n.t('unknownPage');
            platformInfo.querySelector('.platform-icon').textContent = '❓';
            exportChatGPT.disabled = true;
            exportDeepSeek.disabled = true;
            status.textContent = i18n.t('cannotGetPageInfo');
        }
    });
    
    // ChatGPT 导出按钮点击事件
    exportChatGPT.addEventListener('click', function() {
        if (exportChatGPT.disabled) return;
        handleExport('chatgpt');
    });
    
    // DeepSeek 导出按钮点击事件
    exportDeepSeek.addEventListener('click', function() {
        if (exportDeepSeek.disabled) return;
        handleExport('deepseek');
    });

    // Gemini 导出按钮点击事件
    exportGemini.addEventListener('click', function() {
        if (exportGemini.disabled) return;
        handleExport('gemini');
    });
    
    function handleExport(platform) {
        const exportBtn = platform === 'chatgpt' ? exportChatGPT : 
                         platform === 'deepseek' ? exportDeepSeek : exportGemini;
        exportBtn.disabled = true;
        status.textContent = i18n.t('parsingConversation', {platform: platform.toUpperCase()});
        status.className = 'status-message loading';
        
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            const tab = tabs[0];
            
            // 根据平台选择正确的脚本文件
            const scriptFile = platform === 'deepseek' ? 
                'content_scripts/deepseek.js' : 
                platform === 'gemini' ? 'content_scripts/gemini.js' : 'content_scripts/chatgpt.js';
            
            // 首先检查内容脚本是否已注入
            console.log(`[AI-ThreadStash] Checking if ${platform} content script is injected`);
            chrome.tabs.sendMessage(tab.id, {action: 'ping'}, function(response) {
                if (chrome.runtime.lastError) {
                    console.log(`[AI-ThreadStash] Ping failed: ${chrome.runtime.lastError.message}`);
                }
                
                if (chrome.runtime.lastError || !response) {
                    // 内容脚本未注入，尝试重新注入
                    console.log(`[AI-ThreadStash] ${platform} content script not injected, injecting now`);
                    status.textContent = i18n.t('injectingScript');
                    
                    chrome.scripting.executeScript({
                        target: {tabId: tab.id},
                        files: [scriptFile]
                    }).then(() => {
                        console.log(`[AI-ThreadStash] ${platform} content script injected successfully`);
                        // 脚本注入成功，发送导出消息
                        sendExportMessage(tab.id, platform);
                    }).catch(error => {
                        console.error(`[AI-ThreadStash] ${platform} script injection failed:`, error);
                        status.textContent = i18n.t('injectionFailed') + ': ' + error.message;
                        status.className = 'status-message error';
                        exportBtn.disabled = false;
                    });
                } else {
                    // 内容脚本已就绪，直接发送导出消息
                    console.log(`[AI-ThreadStash] ${platform} content script already injected`);
                    sendExportMessage(tab.id, platform);
                }
            });
        });
    }
    
    function sendExportMessage(tabId, platform) {
        const exportBtn = platform === 'chatgpt' ? exportChatGPT : 
                         platform === 'deepseek' ? exportDeepSeek : exportGemini;
        
        console.log(`[AI-ThreadStash] Sending export message to ${platform} content script`);
        
        // 设置超时防止挂起
        const timeout = setTimeout(() => {
            console.log(`[AI-ThreadStash] Export request timeout for ${platform}`);
            status.textContent = i18n.t('requestTimeout');
            status.className = 'status-message error';
            exportBtn.disabled = false;
        }, 10000);
        
        chrome.tabs.sendMessage(tabId, {action: 'export'}, function(response) {
            clearTimeout(timeout);
            
            if (chrome.runtime.lastError) {
                const errorMsg = chrome.runtime.lastError.message;
                // Chrome runtime error
                status.textContent = i18n.t('parsingFailed') + ': ' + errorMsg;
                status.className = 'status-message error';
                exportBtn.disabled = false;
                return;
            }
            
            // Export response received
            
            if (response && response.success) {
                // 对于Gemini，只要内容解析成功就认为是导出成功
                // 实际的预览页面打开由background script处理
                if (platform === 'gemini') {
                    status.textContent = i18n.t('exportSuccess');
                    status.className = 'status-message success';
                    console.log('[AI-ThreadStash] Gemini export successful, preview will be opened by background script');
                    
                    // 关闭弹窗
                    setTimeout(() => window.close(), 1000);
                } else {
                    // 对于其他平台，使用正常的流程
                    status.textContent = i18n.t('exportSuccess');
                    status.className = 'status-message success';
                    
                    if (response.key) {
                        chrome.tabs.create({
                            url: chrome.runtime.getURL(`preview/preview.html?key=${response.key}`)
                        });
                    } else {
                        console.warn('[AI-ThreadStash] Export successful but no preview key provided');
                    }
                    
                    // 关闭弹窗
                    setTimeout(() => window.close(), 1000);
                }
            } else {
                // Export failed - handle various error response formats
                let errorMsg = '未知错误';
                
                if (response) {
                    if (response.error) {
                        errorMsg = response.error;
                    } else if (response.message) {
                        errorMsg = response.message;
                    } else if (response.success === false) {
                        errorMsg = '导出操作失败';
                    } else {
                        errorMsg = '响应格式错误: ' + JSON.stringify(response);
                    }
                } else {
                    errorMsg = '无响应数据';
                }
                
                console.error(`[AI-ThreadStash] Export failed for ${platform}:`, JSON.stringify(response, null, 2));
                status.textContent = i18n.t('exportFailed') + ': ' + errorMsg;
                status.className = 'status-message error';
                exportBtn.disabled = false;
            }
        });
    }
});