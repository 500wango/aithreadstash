// 简单的国际化实现
const i18n = {
    translations: {
        'user': '用户',
        'assistant': '助手',
        'exportTime': '导出时间',
        'source': '来源',
        'previewTitle': 'AI ThreadStash - 对话预览',
        'print': '打印',
        'downloadMd': '下载 Markdown',
        'downloadJson': '下载 JSON',
        'copyRichText': '复制为富文本',
        'loading': '加载中...',
        'loadingConversation': '正在加载对话内容...',
        'noConversationDataToDownload': '没有对话数据可供下载',
        'noConversationDataToCopy': '没有对话数据可供复制',
        'downloadStarted': '下载已开始',
        'downloadFailed': '下载失败',
        'markdownCopySuccess': 'Markdown 复制成功',
        'richTextCopySuccess': '富文本复制成功',
        'copyFailed': '复制失败'
    },
    
    t: function(key, params = {}) {
        let translation = this.translations[key] || key;
        
        // 替换参数
        for (const [param, value] of Object.entries(params)) {
            translation = translation.replace(`{${param}}`, value);
        }
        
        return translation;
    },
    
    getCurrentLanguage: function() {
        return 'zh_CN';
    }
};